<?php
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');
if (!defined('DB_NAME')) define('DB_NAME', 'cvedata');
if (!defined('API_BASE_URL')) define('API_BASE_URL', 'https://services.nvd.nist.gov/rest/json/cves/2.0');
?>
